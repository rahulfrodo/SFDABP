1. SOFR_constrained.html and FLCM_constrained.html show code and illustration of the shape constrained estimation method and testing method in SOFR and FLCM.  

2. SOFR_constrained.Rmd and FLCM_constrained.Rmd file contains the code for the same.

3. Currently supports functional data on dense grid.

4. Functions (source the SFDABP.R file for loading all the following functions)
Currently implements shape constrained SOFR and FLCM for dense data as develped in the paper. Also applicable for FOSR (specical case of FLCM with time-invariant predictors), supply scalar covariate X[i] as matrix as X[i,j] = X[i] for all j.  

i) Cross-validation for choosing degree of Bernstein polynomial basis in SOFR.

@N1: Degree of Bernstein polynomial basis.
@y: Scalar response.
@X: Functional covariate on a grid, n * m matrix.
T: Equispaced time-grid of functional observations.
constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
Use: cv.SOFR.con(N1,y,X,T,constr="positive")

ii) Function for shape constrained estimation in SOFR.

@N1: Degree of Bernstein polynomial basis.
@y: Scalar response.
@X: Functional covariate on a grid, n * m matrix.
T: Equispaced time-grid of functional observations.
constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
Use: SOFR.con(N1,y,X,T,n2=m,constr="positive")

iii) Function for testing shape constraints in SOFR.
@N1: Degree of Bernstein polynomial basis.
@y: Scalar response.
@X: Functional covariate on a grid, n * m matrix.
T: Equispaced time-grid of functional observations.
constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
Use: BPtest.SOFR.con(y,X,T,N1=4,constr="positive")

iv) Cross-validation for choosing degree of Bernstein polynomial basis in FLCM.
@N1: Degree of Bernstein polynomial basis.
@Y: Functional response on a grid, n * m matrix.
@X: Functional covariate on a grid, n * m matrix.
T: Equispaced time-grid of functional observations.
constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
Use: cv.FLCM.con(N1,Y,X,T,constr="positive")

v) Function for shape constrained estimation in FLCM.
@N1: Degree of Bernstein polynomial basis.
@Y: Functional response on a grid, n * m matrix.
@X: Functional covariate on a grid, n * m matrix.
T: Equispaced time-grid of functional observations.
constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
Use: FLCM.con(N1,Y,X,T,n2=m,constr="positive")

vi) Function for testing shape constraints in FLCM.
@N1: Degree of Bernstein polynomial basis.
@Y: Functional response on a grid, n * m matrix.
@X: Functional covariate on a grid, n * m matrix.
T: Equispaced time-grid of functional observations.
constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
BPtest.FLCM.con(Y,X,T,N1=5,constr="positive")
