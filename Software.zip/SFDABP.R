#@N1: Degree of Bernstein polynomial basis.
#@y: Scalar response.
#@X: Functional covariate on a grid, n * m matrix.
#T: Equispaced time-grid of functional observations.
#constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
############CV function FOR CHOOSING N, degree of BP##################
cv.SOFR.con<-function(N1,y,X,T,constr="positive")
{ n<-length(y)
library(caret)
set.seed(1)
find<-createFolds(y=c(1:n), k = 5, list = FALSE, returnTrain = FALSE)
cvscore<-c()
for (v in 1:5)
{tempind=which(find==v)
X1 <- NULL
for(k in 0:N1){
  X1 <- cbind(X1, dbeta(T, shape1=(k+1), shape2=N1-k+1))
}
nte<-length(tempind)
ntr<-n-nte
W<-matrix(0,N,(N1+1))
for(i in 1:n)
{for (k in 1:ncol(X1))
{
  W[i,k]<-mean(X[i,]*X1[,k])
}
}

Wtr<-W[-tempind,]
Wte<-W[tempind,]
ytr<-y[-tempind]
yte<-y[tempind]

library(restriktor)
glmod<-lm(ytr~Wtr)
summary(glmod)

if(constr=="positive"){
  A1<-diag(ncol(X1))
  A<-cbind(rep(0,nrow(A1)),A1)
  b=rep(0,nrow(A))
}

if(constr=="negative"){
  A1<--diag(ncol(X1))
  A<-cbind(rep(0,nrow(A1)),A1)
  b=rep(0,nrow(A))
}

if(constr=="dec"){
  A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
  for(i in 1:(N1))
  {A1[i,i]=1
  A1[i,(i+1)]=-1}
  A<-cbind(rep(0,nrow(A1)),A1)
  b=rep(0,nrow(A))
}
if(constr=="inc"){
  A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
  for(i in 1:(N1))
  {A1[i,i]=-1
  A1[i,(i+1)]=1}
  A<-cbind(rep(0,nrow(A1)),A1)
  b=rep(0,nrow(A))
}

if(constr=="convex"){
  A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
  for(i in 1:(N1-1))
  {A1[i,i]=1
  A1[i,i+1]=-2
  A1[i,i+2]=1
  }
  A<-cbind(rep(0,nrow(A1)),A1)
  b=rep(0,nrow(A))
}

if(constr=="concave"){
  A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
  for(i in 1:(N1-1))
  {A1[i,i]=-1
  A1[i,i+1]=2
  A1[i,i+2]=-1
  }
  A<-cbind(rep(0,nrow(A1)),A1)
  b=rep(0,nrow(A))
}

fit.con <- restriktor(glmod, constraints = A,rhs=b,neq=0)
betares<- coef(fit.con) 
Xtemat<-cbind(rep(1,nte),Wte)
ypred<-as.numeric(Xtemat%*%betares)
cvscore[v]<- mean((yte-ypred)^2)
}
cverror<-mean(cvscore)
return(cverror)
}

#Function for shape constrained estimation.
#@N1: Degree of Bernstein polynomial basis.
#@y: Scalar response.
#@X: Functional covariate on a grid, n * m matrix.
#T: Equispaced time-grid of functional observations.
#constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
SOFR.con<-function(N1,y,X,T,n2=m,constr="positive"){
  m<-length(T)
  tpred<-seq(0,1,l=n2)
  X1 <- NULL
  for(k in 0:N1){
    X1 <- cbind(X1, dbeta(T, shape1=(k+1), shape2=N1-k+1))
  }
  
  W<-matrix(0,N,(N1+1))
  for(i in 1:N)
  {for (k in 1:ncol(X1))
  {
    W[i,k]<-mean(X[i,]*X1[,k])
  }
  }
  
  library(restriktor)
  glmod<-lm(y~W)
  summary(glmod)
  if(constr=="positive"){
    A1<-diag(ncol(X1))
    A<-cbind(rep(0,nrow(A1)),A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="negative"){
    A1<--diag(ncol(X1))
    A<-cbind(rep(0,nrow(A1)),A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="dec"){
    A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1))
    {A1[i,i]=1
    A1[i,(i+1)]=-1}
    A<-cbind(rep(0,nrow(A1)),A1)
    b=rep(0,nrow(A))
  }
  if(constr=="inc"){
    A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1))
    {A1[i,i]=-1
    A1[i,(i+1)]=1}
    A<-cbind(rep(0,nrow(A1)),A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="convex"){
    A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1-1))
    {A1[i,i]=1
    A1[i,i+1]=-2
    A1[i,i+2]=1
    }
    A<-cbind(rep(0,nrow(A1)),A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="concave"){
    A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1-1))
    {A1[i,i]=-1
    A1[i,i+1]=2
    A1[i,i+2]=-1
    }
    A<-cbind(rep(0,nrow(A1)),A1)
    b=rep(0,nrow(A))
  }
  
  fit.con <- restriktor(glmod, constraints = A,rhs=b,neq=0)
  betares<- coef(fit.con) 
  ypred<-fit.con$fitted
  
  beta1est<-function(x){
    
    n<-length(x)
    X1 <- NULL
    for(k in 0:N1){
      X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
    }
    pred<-as.numeric(X1%*%betares[-1])
    pred
  }
  coef <- beta1est(tpred)
  
  betaresun<-coef(glmod)
  Wreal<-cbind(rep(1,N),W)
  Omegahat<-(t(Wreal)%*%Wreal)*(1/N)
  ###sigmahat beta ur###
  sigmahat_ur<-as.matrix(vcov(glmod))
  L_omega<-t(chol(Omegahat))
  library(MASS)
  zgen<-function(...)
  {betacan_ur<-mvrnorm(n=1,mu=betaresun,Sigma=sigmahat_ur)
  Ystar<-as.numeric(L_omega%*%(betacan_ur))
  Xstar<-L_omega
  library(quadprog)
  #ATb> b0.
  Dmat = t(Xstar) %*% Xstar
  Amat = t(A) 
  bvec = b
  dvec = t(Xstar) %*% Ystar
  out<-solve.QP(Dmat = Dmat, dvec = dvec, Amat = Amat, bvec = bvec, meq = 0, factorized = F)
  betaproj<-out$solution #out$solution
  betaproj  
  }
  betagenmat<-sapply(1:2000,zgen)
  betagenmat<-t(betagenmat)
  
  bootmatest<-matrix(0,2000,m)
  for(b in 1:2000){
    betatemp<-betagenmat[b,]
    beta1estboot<-function(x){
      
      n<-length(x)
      X1 <- NULL
      for(k in 0:N1){
        X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
      }
      pred<-as.numeric(X1%*%betatemp[-1])
      pred
    }
    bootmatest[b,]<-beta1estboot(T)
  }
  lb<-apply(bootmatest,2, quantile,probs=0.025)
  ub<-apply(bootmatest,2, quantile,probs=0.975)
  result<-list(betaSOFR=coef,yhat=ypred,lb=lb,ub=ub)
  return(result)
}

#Function for testing shape constraints.
#@N1: Degree of Bernstein polynomial basis.
#@y: Scalar response.
#@X: Functional covariate on a grid, n * m matrix.
#T: Equispaced time-grid of functional observations.
#constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
BPtest.SOFR.con<-function(y,X,T,N1=4,constr="positive"){
  BPfit.sofr.con<-function(y,X,T,N1=4,con=constr){
    n<-length(y)
    m<-length(T)
    X1 <- NULL
    for(k in 0:N1){
      X1 <- cbind(X1, dbeta(T, shape1=(k+1), shape2=N1-k+1))
    }
    
    W<-matrix(0,N,(N1+1))
    for(i in 1:N)
    {for (k in 1:ncol(X1))
    {
      W[i,k]<-mean(X[i,]*X1[,k])
    }
    }
    ####fitting uncons model########
    
    library(restriktor)
    glmod<-lm(y~W)
    resfull<-glmod$residuals
    rssfull<-sum(glmod$residuals^2)
    #summary(glmod)
    
    ####fitting cons model 
    if(con=="positive"){
      A1<-diag(ncol(X1))
      A<-cbind(rep(0,nrow(A1)),A1)
      b=rep(0,nrow(A))
    }
    
    if(con=="negative"){
      A1<--diag(ncol(X1))
      A<-cbind(rep(0,nrow(A1)),A1)
      b=rep(0,nrow(A))
    }
    
    if(con=="dec"){
      A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
      for(i in 1:(N1))
      {A1[i,i]=1
      A1[i,(i+1)]=-1}
      A<-cbind(rep(0,nrow(A1)),A1)
      b=rep(0,nrow(A))
    }
    if(con=="inc"){
      A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
      for(i in 1:(N1))
      {A1[i,i]=-1
      A1[i,(i+1)]=1}
      A<-cbind(rep(0,nrow(A1)),A1)
      b=rep(0,nrow(A))
    }
    
    if(con=="convex"){
      A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
      for(i in 1:(N1-1))
      {A1[i,i]=1
      A1[i,i+1]=-2
      A1[i,i+2]=1
      }
      A<-cbind(rep(0,nrow(A1)),A1)
      b=rep(0,nrow(A))
    }
    
    if(con=="concave"){
      A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
      for(i in 1:(N1-1))
      {A1[i,i]=-1
      A1[i,i+1]=2
      A1[i,i+2]=-1
      }
      A<-cbind(rep(0,nrow(A1)),A1)
      b=rep(0,nrow(A))
    }
    
    
    fit.con <- restriktor(glmod, constraints = A,rhs=b,neq=0)
    betares<- coef(fit.con) 
    alpha_c=betares[1]
    
    beta1est<-function(x){
      
      n<-length(x)
      X1 <- NULL
      for(k in 0:N1){
        X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
      }
      pred<-as.numeric(X1%*%betares[-1])
      pred
    }
    beta_c <- beta1est(T)
    rssnull<-sum(fit.con$residuals^2)
    Tobs<-(rssnull-rssfull)/(rssfull)
    RESULT<-list(resfull=resfull,alpha_c=alpha_c,beta_c=beta_c,Tobs=Tobs)
    return(RESULT)
  }
  out<-BPfit.sofr.con(y,X,T,N1=N1,con=constr)
  resfull<-out$resfull
  alpha_c<-out$alpha_c
  beta_c<-out$beta_c
  Tobs<-out$Tobs
  ###########Do bootstrap###############
  B=100
  ###generate TBoot###########
  bootsofr<-function(...)
  {indboot<-sample(c(1:n), n, replace = TRUE)
  resboot<-resfull[indboot]
  lftermcon<-as.numeric((1/m)*X%*%beta_c)
  yboot<-alpha_c+lftermcon+resboot
  outboot<-BPfit.sofr.con(yboot,X,T,N1=4,con = constr)
  Tboot<-outboot$Tobs
  return(Tboot)  
  }
  bootT<-sapply(1:B, bootsofr)
  pvalue<-mean(bootT>=Tobs) 
  return(pvalue)
}

#Perform cross-validation for choosing N1, degree of Bernstein polynomial.
#@N1: Degree of Bernstein polynomial basis.
#@Y: Functional response on a grid, n * m matrix.
#@X: Functional covariate on a grid, n * m matrix.
#T: Equispaced time-grid of functional observations.
#constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
############CV function FOR CHOOSING N, degree of BP##################
cv.FLCM.con<-function(N1,Y,X,T,constr="positive"){
  n<-nrow(Y)
  library(caret)
  set.seed(1)
  find<-createFolds(y=c(1:n), k = 5, list = FALSE, returnTrain = FALSE)
  cvscore<-c()
  for (v in 1:5)
  {tempind=which(find==v)
  m<-length(T)
  X1 <- NULL
  for(k in 0:N1){
    X1 <- cbind(X1, dbeta(T, shape1=(k+1), shape2=N1-k+1))
  }
  nte<-length(tempind)
  ntr<-n-nte
  Btr<-NULL
  for(i in 1:ntr)
  {Btr<-rbind(Btr,X1)}
  
  Bte<-NULL
  for(i in 1:nte)
  {Bte<-rbind(Bte,X1)}
  Yvectr<-as.vector(t(Y[-tempind,]))
  Yvecte<-as.vector(t(Y[tempind,]))
  B1<-list()
  for(i in 1:n)
  {B1[[i]]<-matrix(0,m,ncol(Btr))
  for(k in 1:m){
    B1[[i]][k,]<-X[i,k]*X1[k,]
  }
  }
  
  B1tr<-B1[-tempind]
  B1te<-B1[tempind]
  GrandB1tr<-Reduce(rbind,B1tr)
  GrandB1te<-Reduce(rbind,B1te)
  library(restriktor)
  glmod<-lm(Yvectr~-1+Btr+GrandB1tr)
  #summary(glmod)
  residvec<-glmod$residuals
  resmat<-matrix(residvec,ntr,m,byrow = TRUE)
  library(refund)
  fpca1<-fpca.sc(resmat,center = TRUE, nbasis=15,argvals=T,pve=0.99,var=TRUE)
  if(length(fpca1$evalues)>1)
  {sigmat<-fpca1$efunctions%*%diag(fpca1$evalues)%*%t(fpca1$efunctions) + fpca1$sigma2*diag(m)}
  if(length(fpca1$evalues)==1)
  {sigmat<-fpca1$evalues*fpca1$efunctions%*%t(fpca1$efunctions) + fpca1$sigma2*diag(m)}
  R<-chol(sigmat)
  L<-t(R)
  Linv<-forwardsolve(L, diag(dim(L)[1]))
  llist<-replicate(ntr,Linv,simplify = FALSE)
  library(Matrix)
  Linvhalf<-bdiag(llist)
  NewBtr<-as.matrix(Linvhalf%*%Btr)
  NewB1tr<-as.matrix(Linvhalf%*%GrandB1tr)
  NewYtr<-as.matrix(Linvhalf%*%Yvectr)
  glmodpw<-lm(NewYtr~-1+NewBtr+NewB1tr)
  #summary(glmodpw)
  
  if(constr=="positive"){
    A1<-diag(ncol(X1))
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="negative"){
    A1<--diag(ncol(X1))
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="dec"){
    A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1))
    {A1[i,i]=1
    A1[i,(i+1)]=-1}
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  if(constr=="inc"){
    A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1))
    {A1[i,i]=-1
    A1[i,(i+1)]=1}
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="convex"){
    A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1-1))
    {A1[i,i]=1
    A1[i,i+1]=-2
    A1[i,i+2]=1
    }
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="concave"){
    A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1-1))
    {A1[i,i]=-1
    A1[i,i+1]=2
    A1[i,i+2]=-1
    }
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  
  fit.con <- restriktor(glmodpw, constraints = A,rhs=b,neq=0)
  betares<- coef(fit.con)   ###same as lm #standard errors also same
  Xtemat<-cbind(Bte,GrandB1te)
  Yvectepred<-as.numeric(Xtemat%*%betares)
  cvscore[v]<- mean((Yvectepred-Yvecte)^2)
  }
  cverror<-mean(cvscore)
  return(cverror)
}

#Function for shape constrained estimation.
#@N1: Degree of Bernstein polynomial basis.
#@Y: Functional response on a grid, n * m matrix.
#@X: Functional covariate on a grid, n * m matrix.
#T: Equispaced time-grid of functional observations.
#constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
FLCM.con<-function(N1,Y,X,T,n2=m,constr="positive"){
  Yvec<-as.vector(t(Y))
  m<-length(T)
  tpred<-seq(0,1,l=n2)
  X1 <- NULL
  for(k in 0:N1){
    X1 <- cbind(X1, dbeta(T, shape1=(k+1), shape2=N1-k+1))
  }
  B<-NULL
  for(i in 1:n)
  {B<-rbind(B,X1)}
  #calculate Z_i
  
  B1<-list()
  for(i in 1:n)
  {B1[[i]]<-matrix(0,m,ncol(B))
  for(k in 1:m){
    B1[[i]][k,]<-X[i,k]*X1[k,]
  }
  }
  GrandB1<-Reduce(rbind,B1)
  library(restriktor)
  glmod<-lm(Yvec~-1+B+GrandB1)
  residvec<-glmod$residuals
  resmat<-matrix(residvec,n,m,byrow = TRUE)
  library(refund)
  fpca1<-fpca.sc(resmat,center = TRUE, nbasis=15,argvals=T,pve=0.99,var=TRUE)
  if(length(fpca1$evalues)>1)
  {sigmat<-fpca1$efunctions%*%diag(fpca1$evalues)%*%t(fpca1$efunctions) + fpca1$sigma2*diag(m)}
  if(length(fpca1$evalues)==1)
  {sigmat<-fpca1$evalues*fpca1$efunctions%*%t(fpca1$efunctions) + fpca1$sigma2*diag(m)}
  R<-chol(sigmat)
  L<-t(R)
  Linv<-forwardsolve(L, diag(dim(L)[1]))
  llist<-replicate(n,Linv,simplify = FALSE)
  library(Matrix)
  Linvhalf<-bdiag(llist)
  NewB<-as.matrix(Linvhalf%*%B)
  NewB1<-as.matrix(Linvhalf%*%GrandB1)
  NewY<-as.matrix(Linvhalf%*%Yvec)
  glmodpw<-lm(NewY~-1+NewB+NewB1)
  if(constr=="positive"){
    A1<-diag(ncol(X1))
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="negative"){
    A1<--diag(ncol(X1))
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="dec"){
    A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1))
    {A1[i,i]=1
    A1[i,(i+1)]=-1}
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  if(constr=="inc"){
    A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1))
    {A1[i,i]=-1
    A1[i,(i+1)]=1}
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="convex"){
    A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1-1))
    {A1[i,i]=1
    A1[i,i+1]=-2
    A1[i,i+2]=1
    }
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  if(constr=="concave"){
    A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
    for(i in 1:(N1-1))
    {A1[i,i]=-1
    A1[i,i+1]=2
    A1[i,i+2]=-1
    }
    A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
    A<-cbind(A2,A1)
    b=rep(0,nrow(A))
  }
  
  fit.con <- restriktor(glmodpw, constraints = A,rhs=b,neq=0)
  betares<- coef(fit.con)   ###same as lm #standard errors also same
  Xtemat<-cbind(B,GrandB1)
  ypred<-as.numeric(Xtemat%*%betares)
  
  beta1est<-function(x){
    n<-length(x)
    X1 <- NULL
    for(k in 0:N1){
      X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
    }
    a<-(N1+1)+1
    b<-2*(N1+1)
    pred<-as.numeric(X1%*%betares[a:b])
    pred
  }
  beta0est<-function(x){
    n<-length(x)
    X1 <- NULL
    for(k in 0:N1){
      X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
    }
    a<-1
    b<-1*(N1+1)
    pred<-as.numeric(X1%*%betares[a:b])
    pred
  }
  beta0t <- beta0est(tpred)
  beta1t <- beta1est(tpred)
  Yhat<-matrix(ypred,n,m,byrow = TRUE)
  ###projection based confidence intervals###
  betaresun<-coef(glmodpw)
  Xtrmat<-cbind(NewB,NewB1)
  Omegahat<-(t(Xtrmat)%*%Xtrmat)*(1/n)
  sigmahat_ur<-as.matrix(vcov(glmodpw))
  L_omega<-t(chol(Omegahat))
  library(MASS)
  zgen<-function(...)
  {betacan_ur<-mvrnorm(n=1,mu=betaresun,Sigma=sigmahat_ur)
  Ystar<-as.numeric(L_omega%*%(betacan_ur))
  Xstar<-L_omega
  library(quadprog)
  #ATb> b0.
  Dmat = t(Xstar) %*% Xstar
  Amat = t(A) 
  bvec = b
  dvec = t(Xstar) %*% Ystar
  out<-solve.QP(Dmat = Dmat, dvec = dvec, Amat = Amat, bvec = bvec, meq = 0, factorized = F)
  betaproj<-out$solution #out$solution
  betaproj  
  }
  betagenmat<-sapply(1:10000,zgen)
  betagenmat<-t(betagenmat)
  
  bootmat0est<-matrix(0,10000,m)
  for(k in 1:10000){
    betatemp<-betagenmat[k,]
    beta0estboot<-function(x){
      
      n<-length(x)
      X1 <- NULL
      for(k in 0:N1){
        X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
      }
      c<-1
      d<-1*(N1+1)
      pred<-as.numeric(X1%*%betatemp[c:d])
      pred
    }
    bootmat0est[k,]<-beta0estboot(T)
  }
  lb0<-apply(bootmat0est,2, quantile,probs=0.025)
  ub0<-apply(bootmat0est,2, quantile,probs=0.975)  
  
  
  
  bootmat1est<-matrix(0,10000,m)
  for(k in 1:10000){
    betatemp<-betagenmat[k,]
    beta1estboot<-function(x){
      
      n<-length(x)
      X1 <- NULL
      for(k in 0:N1){
        X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
      }
      c<-(N1+1)+1
      d<-2*(N1+1)
      pred<-as.numeric(X1%*%betatemp[c:d])
      pred
    }
    bootmat1est[k,]<-beta1estboot(T)
  }
  lb1<-apply(bootmat1est,2, quantile,probs=0.025)
  ub1<-apply(bootmat1est,2, quantile,probs=0.975)  
  result<-list(beta0t=beta0t,beta1t=beta1t,Yhat=Yhat,lb0=lb0,ub0=ub0,lb1=lb1,ub1=ub1)
  return(result)
}

#Function for testing shape constraints.
#@N1: Degree of Bernstein polynomial basis.
#@Y: Functional response on a grid, n * m matrix.
#@X: Functional covariate on a grid, n * m matrix.
#T: Equispaced time-grid of functional observations.
#constr: Constraints, one of positive,negative,inc (increasing), dec (decreasing), convex, concave.
BPtest.FLCM.con<-function(Y,X,T,N1=5,constr="positive"){
  BPfit.FLCM.con<-function(Y,X,T,N1=5,con=constr){
    n<-nrow(Y)
    m<-length(T)
    Yvec<-as.vector(t(Y))
    X1 <- NULL
    for(k in 0:N1){
      X1 <- cbind(X1, dbeta(T, shape1=(k+1), shape2=N1-k+1))
    }
    B<-NULL
    for(i in 1:n)
    {B<-rbind(B,X1)}
    #calculate Z_i
    
    B1<-list()
    for(i in 1:n)
    {B1[[i]]<-matrix(0,m,ncol(B))
    for(k in 1:m){
      B1[[i]][k,]<-X[i,k]*X1[k,]
    }
    }
    GrandB1<-Reduce(rbind,B1)
    library(restriktor)
    glmodpw<-lm(Yvec~-1+B+GrandB1)
    betaresun<- coef(glmodpw)   ###same as lm #standard errors also same
    resfull<-glmodpw$residuals
    resfullmat<-matrix(resfull,n,m,byrow = TRUE)
    rssfull<-sum(glmodpw$residuals^2)
    if(con=="positive"){
      A1<-diag(ncol(X1))
      A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
      A<-cbind(A2,A1)
      b=rep(0,nrow(A))
    }
    
    if(con=="negative"){
      A1<--diag(ncol(X1))
      A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
      A<-cbind(A2,A1)
      b=rep(0,nrow(A))
    }
    
    if(con=="dec"){
      A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
      for(i in 1:(N1))
      {A1[i,i]=1
      A1[i,(i+1)]=-1}
      A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
      A<-cbind(A2,A1)
      b=rep(0,nrow(A))
    }
    if(con=="inc"){
      A1<-matrix(0,nrow=N1,ncol=(N1+1),byrow = TRUE)
      for(i in 1:(N1))
      {A1[i,i]=-1
      A1[i,(i+1)]=1}
      A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
      A<-cbind(A2,A1)
      b=rep(0,nrow(A))
    }
    
    if(con=="convex"){
      A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
      for(i in 1:(N1-1))
      {A1[i,i]=1
      A1[i,i+1]=-2
      A1[i,i+2]=1
      }
      A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
      A<-cbind(A2,A1)
      b=rep(0,nrow(A))
    }
    
    if(con=="concave"){
      A1<-matrix(0,nrow=(N1-1),ncol=(N1+1),byrow = TRUE)
      for(i in 1:(N1-1))
      {A1[i,i]=-1
      A1[i,i+1]=2
      A1[i,i+2]=-1
      }
      A2<-matrix(0,nrow = nrow(A1),ncol = (N1+1))
      A<-cbind(A2,A1)
      b=rep(0,nrow(A))
    }
    fit.con <- restriktor(glmodpw, constraints = A,rhs=b,neq=0)
    betares<- coef(fit.con)   ###same as lm #standard errors also same
    rssnull<-sum(fit.con$residuals^2)
    Tobs<-(rssnull-rssfull)/(rssfull)
    beta1est<-function(x){
      
      n<-length(x)
      X1 <- NULL
      for(k in 0:N1){
        X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
      }
      a<-(N1+1)+1
      b<-2*(N1+1)
      pred<-as.numeric(X1%*%betares[a:b])
      pred
    }
    beta1_c <- beta1est(T)
    beta0est<-function(x){
      
      n<-length(x)
      X1 <- NULL
      for(k in 0:N1){
        X1 <- cbind(X1, dbeta(x, shape1=(k+1), shape2=N1-k+1))
      }
      a<-1
      b<-1*(N1+1)
      pred<-as.numeric(X1%*%betares[a:b])
      pred
    }
    beta0_c <- beta0est(T)
    RESULT<-list(resfullmat=resfullmat,beta0_c=beta0_c,beta1_c=beta1_c,Tobs=Tobs)
    return(RESULT)
  }
  out<-BPfit.FLCM.con(Y,X,T,N1=5,con=constr)
  resfullmat<-out$resfullmat
  beta0_c<-out$beta0_c
  beta1_c<-out$beta1_c
  Tobs<-out$Tobs
  
  ###########Do bootstrap###############
  B=100
  ###generate TBoot###########
  bootFLCM<-function(...)
  {indboot<-sample(c(1:n), n, replace = TRUE)
  resboot<-resfullmat[indboot,]
  Yboot<-matrix(0,n,m)
  for(i in 1:n)
  {for(l in 1: length(T)){
    Yboot[i,l]= beta0_c[l]+ X[i,l]*(beta1_c[l]) +resboot[i,l] #
  }
  }
  outboot<-BPfit.FLCM.con(Yboot,X,T,N1=5,con=constr)
  Tboot<-outboot$Tobs
  return(Tboot)  
  }
  bootT<-sapply(1:B, bootFLCM)
  pvalue<-mean(bootT>=Tobs) #gen
  return(pvalue)
}







